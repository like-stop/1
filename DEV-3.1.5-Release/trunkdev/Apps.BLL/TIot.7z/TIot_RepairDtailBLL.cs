﻿using Apps.Common;
using Apps.Models;
using System.Linq;
using System.Collections.Generic;
using System.Linq;
using System;
using Apps.Models.TIot;

namespace Apps.BLL.TIot
{
    public  partial class TIot_RepairDtailBLL
    {

        public override List<TIot_RepairDtailModel> CreateModelList(ref IQueryable<TIot_RepairDtail> queryData)
        {
           

            List<TIot_RepairDtailModel> modelList = (from r in queryData
                                              select new TIot_RepairDtailModel
                                              {
                                                  Content = r.Content,
                                                  CreateTime = r.CreateTime,
                                                  Files = r.Files,
                                                  Id = r.Id,
                                                  Sender = r.Sender,
                                                  WorkId = r.WorkId,
                                              }).ToList();

            foreach (var r in modelList)
            {
                SysUser user = m_userRep.GetById(r.Sender);
                if (user != null)
                {
                    r.TrueName = user.TrueName;
                    r.Photo = user.Photo;
                }

               
            }

            return modelList;
        }
    }
 }

