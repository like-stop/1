﻿using Apps.Common;
using Apps.Models;
using System.Linq;
using System.Collections.Generic;
using System.Linq;
using System;
using Apps.Models.TIot;

namespace Apps.BLL.TIot
{
    public  partial class TIot_RepairBillBLL
    {

        public override List<TIot_RepairBillModel> CreateModelList(ref IQueryable<TIot_RepairBill> queryData)
        {

            List<TIot_RepairBillModel> modelList = (from r in queryData
                                              select new TIot_RepairBillModel
                                              {
                                                  Attach = r.Attach,
                                                  BuyerId = r.BuyerId,
                                                  CreateTime = r.CreateTime,
                                                  Creator = r.Creator,
                                                  Descs = r.Descs,
                                                  EMail = r.EMail,
                                                  Id = r.Id,
                                                  Linker = r.Linker,
                                                  LinkTel = r.LinkTel,
                                                  MachId = r.MachId,
                                                  PRI = r.PRI,
                                                  Status = r.Status,
                                              }).ToList();

            return modelList;
        }


        public override TIot_RepairBillModel GetById(object id)
        {
            if (IsExists(id))
            {
                TIot_RepairBill entity = m_Rep.GetById(id);
                TIot_RepairBillModel model = new TIot_RepairBillModel();
                model.Id = entity.Id;
                model.BuyerId = entity.BuyerId;
                model.MachId = entity.MachId;
                model.PRI = entity.PRI;
                model.Descs = entity.Descs;
                model.Linker = entity.Linker;
                model.LinkTel = entity.LinkTel;
                model.EMail = entity.EMail;
                model.Attach = entity.Attach;
                model.CreateTime = entity.CreateTime;
                model.Creator = entity.Creator;
                SysUser user = m_userRep.GetById(model.Creator);
                model.CreatorName = user.TrueName;
                model.SysUserM = user;
                model.Status = entity.Status;

                return model;
            }
            else
            {
                return null;
            }
        }
    }
 }

